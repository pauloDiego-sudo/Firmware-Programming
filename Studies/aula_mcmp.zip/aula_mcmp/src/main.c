#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <driver/gpio.h>
#include <esp_log.h>

#define RED_LED_GPIO GPIO_NUM_25
#define YELLOW_LED_GPIO GPIO_NUM_26
#define GREEN_LED_GPIO GPIO_NUM_27
#define BUTTON_GPIO GPIO_NUM_33

typedef struct
{
    gpio_num_t gpio;
    uint16_t interval_high_ms;
    uint16_t interval_low_ms;
} led_config_t;

static const led_config_t red_led = {
    .gpio = RED_LED_GPIO,
    .interval_high_ms = 1000,
    .interval_low_ms = 100};

static const led_config_t yellow_led = {
    .gpio = YELLOW_LED_GPIO,
    .interval_high_ms = 500,
    .interval_low_ms = 50};

static const led_config_t green_led = {
    .gpio = GREEN_LED_GPIO,
    .interval_high_ms = 250,
    .interval_low_ms = 25};

static const char *TAG = "main";

static void blink_led(void *args);

static bool blinking = true;

static void IRAM_ATTR button_handler(void *args)
{
    blinking = !blinking;
}

void app_main()
{
    ESP_LOGI(TAG, "blink leds");

    if (xTaskCreate(blink_led, "red_led", 2 * 1024, (void *)&red_led, 1, NULL) != pdPASS)
    {
        ESP_LOGI(TAG, "cannot create the task");
        return;
    }

    if (xTaskCreate(blink_led, "yellow_led", 2 * 1024, (void *)&yellow_led, 1, NULL) != pdPASS)
    {
        ESP_LOGI(TAG, "cannot create the task");
        return;
    }

    if (xTaskCreate(blink_led, "green_led", 2 * 1024, (void *)&green_led, 1, NULL) != pdPASS)
    {
        ESP_LOGI(TAG, "cannot create the task");
        return;
    }

    ESP_LOGI(TAG, "config interrupt service routine");

    gpio_config_t io_conf = {};
    io_conf.intr_type = GPIO_INTR_POSEDGE;
    io_conf.pin_bit_mask = (1ULL << BUTTON_GPIO);
    io_conf.mode = GPIO_MODE_INPUT;
    io_conf.pull_up_en = 0;
    io_conf.pull_down_en = 0;
    gpio_config(&io_conf);

    gpio_install_isr_service(0);
    gpio_isr_handler_add(BUTTON_GPIO, button_handler, NULL);
}

static void blink_led(void *args)
{
    char *NAME = pcTaskGetName(NULL);

    led_config_t *led_config = (led_config_t *)args;
    const gpio_num_t gpio = led_config->gpio;
    const uint16_t interval_high_ms = led_config->interval_high_ms;
    const uint16_t interval_low_ms = led_config->interval_low_ms;

    // sets the GPIO as a output
    gpio_reset_pin(gpio);
    gpio_set_direction(gpio, GPIO_MODE_OUTPUT);

    for (;;)
    {
        if (blinking)
        {
            ESP_LOGI(NAME, "blink");
            gpio_set_level(gpio, 1);
            vTaskDelay(interval_low_ms / portTICK_PERIOD_MS);
            gpio_set_level(gpio, 0);
            vTaskDelay(interval_high_ms / portTICK_PERIOD_MS);
        }
        else
        {
            vTaskDelay(100 / portTICK_PERIOD_MS);
        }
    }
}
